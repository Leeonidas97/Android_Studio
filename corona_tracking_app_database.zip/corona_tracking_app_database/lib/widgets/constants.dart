import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

const kPrimaryColor = Color(0xFF5EC93A);
const kGreyBackground = Color(0xffe0e0e0);
final Color green = HexColor('#5EC93A');